package com.example.mp3player;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javazoom.jl.player.Player;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
public class MP3PlayerApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {

    }
    private Player player;
    private Button playButton;
    private Button pauseButton;
    private Button stopButton;
}
