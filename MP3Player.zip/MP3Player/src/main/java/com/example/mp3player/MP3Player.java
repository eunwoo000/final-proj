import java.io.File;
import javazoom.jl.player.Player;

public class MP3Player {
    private Player player;
    private File songFile;

    public MP3Player(String filePath) {
        this.songFile = new File(filePath);
    }

    public void play() {
        try {
            player = new Player(songFile.toURI().toURL().openStream());
            player.play();
        } catch (Exception e) {
            System.out.println("Error playing the song: " + e.getMessage());
        }
    }

    public void pause() {
        if (player != null) {
            player.close();
        }
    }

    public void stop() {
        if (player != null) {
            player.close();
            player = null;
        }
    }

    public static void main(String[] args) {
        String filePath = "path_to_your_mp3_file.mp3"; // Replace with the actual path to your MP3 file
        MP3Player mp3Player = new MP3Player(filePath);
        mp3Player.play();
    }
}